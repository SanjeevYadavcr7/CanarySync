# CanarySync

Created this package to publish latest canaries version in frontend

It contains a python module to import and a CLI tool.

## Installation

You can easily install the module using `pip`.

## Using the Python module

Once installed, in your python script:

```
from canarysync import updateCanary

```

## Using the CLI command

```
$ canarysync
```